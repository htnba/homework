package fa.homework;

import fa.homework.datamodel.meta.RecordDefinition;
import fa.homework.io.Source;

public class Configuration {
	private Source<?> source;
	private RecordDefinition recordDefinition;

	public RecordDefinition getRecordDefinition(String id) {
		// TODO
		return null;
	}

	public Source<?> getSource(String sourceId) {
		// TODO
		return null;
	}
}
