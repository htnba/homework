/**
 * This package contains interfaces that allow for browsing records from a data set
 */
package fa.homework.datamodel;