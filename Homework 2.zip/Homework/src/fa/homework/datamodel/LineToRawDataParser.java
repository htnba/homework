package fa.homework.datamodel;

public interface LineToRawDataParser<T> {
	public T parse(String line);
}
