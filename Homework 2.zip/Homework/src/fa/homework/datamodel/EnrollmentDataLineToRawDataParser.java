package fa.homework.datamodel;

public class EnrollmentDataLineToRawDataParser<T> implements LineToRawDataParser {
	@Override
	public T parse(String line) {
		String[] splitLine = line.split(",");
		String accountId = splitLine[EnrollmentDataFields.ACCOUNTID.getIndex()];
		String firstName = splitLine[EnrollmentDataFields.FIRSTNAME.getIndex()];
		String lastName = splitLine[EnrollmentDataFields.LASTNAME.getIndex()];
		String addressLine1 = splitLine[EnrollmentDataFields.ADDRESSLINE1.getIndex()];
		String addressLine2 = splitLine[EnrollmentDataFields.ADDRESSLINE2.getIndex()];
		int zipCode = Integer.parseInt(splitLine[EnrollmentDataFields.ZIPCODE.getIndex()]);
		String phoneNumber = splitLine[EnrollmentDataFields.PHONENUMBER.getIndex()];
		long timestamp = Long.parseLong(splitLine[EnrollmentDataFields.ENROLLMENTTIMESTAMP.getIndex()]);

		return new EnrollmentRawData<T>(accountId, firstName, lastName, addressLine1,
				addressLine2, zipCode, phoneNumber, timestamp);
	}
}