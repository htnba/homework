package fa.homework.datamodel;

public enum EnrollmentDataFields {
	ACCOUNTID(0),
	FIRSTNAME(1),
	LASTNAME(2),
	ADDRESSLINE1(3),
	ADDRESSLINE2(4),
	ZIPCODE(5),
	PHONENUMBER(6),
	ENROLLMENTTIMESTAMP(7);

	private int index;
	private EnrollmentDataFields(int index){
		this.index = index;
	}

	public int getIndex() {
		return index;
	}
}
