package fa.homework.datamodel;

public class EnrollmentRawData<T> implements RawData {
	private String accountId;
	private String firstName;
	private String lastName;
	private String addressLine1;
	private String addressLine2;
	private int zipCode;
	private String phoneNumber;
	private long enrollmentTimestamp;

	public EnrollmentRawData(String accountId, String firstName, String lastName, String addressLine1,
			String addressLine2, int zipCode, String phoneNumber, long enrollmentTimestamp) {
		this.accountId = accountId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.enrollmentTimestamp = enrollmentTimestamp;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public long getEnrollmentTimestamp() {
		return enrollmentTimestamp;
	}

	public void setEnrollmentTimestamp(long enrollmentTimestamp) {
		this.enrollmentTimestamp = enrollmentTimestamp;
	}
}
