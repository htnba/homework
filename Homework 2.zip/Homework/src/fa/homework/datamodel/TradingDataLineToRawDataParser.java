package fa.homework.datamodel;

public class TradingDataLineToRawDataParser<T> implements LineToRawDataParser {
	@Override public RawData parse(String line) {
		String[] splitLine = line.split(",");
		long timestamp = Long.parseLong(splitLine[TradingDataFields.TRADETIMESTAMP.getIndex()]);
		String accountId = splitLine[TradingDataFields.ACCOUNTID.getIndex()];
		double tradedValue = Double.parseDouble(splitLine[TradingDataFields.TRADEDVALUE.getIndex()]);
		return new TradingRawData(accountId, timestamp, tradedValue);
	}
}
