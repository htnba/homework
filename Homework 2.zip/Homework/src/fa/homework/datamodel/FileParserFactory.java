//package fa.homework.datamodel;
//
//public class FileParserFactory {
//	public RawData getRawDataFromFileName(String fileName){
////		for(FileTypes fileType: FileTypes.values()){
////			String prefix = fileType.getPrefix();
//			if(fileName.startsWith(FileTypes.ENROLLMENT_FILE.getPrefix())){
//				return ;
//			}
////		}
//	}
//}
