/**
 * This package contains classes about accessing external storage
 */
package fa.homework.io;