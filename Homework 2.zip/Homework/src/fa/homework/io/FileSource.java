package fa.homework.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import fa.homework.datamodel.FileType;
import fa.homework.datamodel.LineToRawDataParser;
import fa.homework.datamodel.LineToRawDataParserFactory;
import fa.homework.datamodel.RawData;

public class FileSource<T extends RawData> implements Source<T> {
	private String filePath;
	private LineToRawDataParserFactory lineToRawDataParserFactory;

	public FileSource(String filePath, LineToRawDataParserFactory lineToRawDataParserFactory) {
		this.filePath = filePath;
		this.lineToRawDataParserFactory = lineToRawDataParserFactory;
	}

	@Override public Iterator<T> iterator() {

		//read file into stream, try-with-resources
		FileType fileType = getFileTypeFromFilePath(this.filePath);
		if(fileType == null){
			// logger.error("unsupported file type encountered. file name is {}", this.fileName);
			return null;
		}
		LineToRawDataParser parser = lineToRawDataParserFactory.getParser(fileType);
		List<T> rawDataList = new ArrayList<>();
//		try (Stream<String> stream = Files.lines(Paths.get(this.filePath))) {
//			stream.forEach(rawDataList.add(parser.parse));
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line;
			while ((line = br.readLine()) != null) {
				rawDataList.add(parser.parse(line));
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return rawDataList.iterator();
	}

	private FileType getFileTypeFromFilePath(String filePath) {
		for(FileType f: FileType.values()){
			if(filePath.startsWith(f.getPrefix()))
				return f;
		}
		return null;
	}
}
