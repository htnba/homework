package fa.homework;

import java.util.List;

import fa.homework.datamodel.DataSet;

/**
 * implement a main entry point that fills a data set with records from a source
 */
public class IngestionService {
	private List<Configuration> configurations;

	public IngestionService(List<Configuration> configurations) {
		this.configurations = configurations;
	}

	public DataSet ingestRecordsFromSource(){
		for(Configuration configuration : this.configurations){

			Source source = configuration.getSource();//where to get the source id from?
		}
	}
}
