/**
 * Homework is a mini project to use in a recruitment process<br/>
 * It provides a small framework about a data model and its meta data.<br/>
 * It contains no implementation when submitted to the candidate.<br/>
 * <br/>
 * Here are example tasks the candidate can do in the homework assignment:
 * <ul>
 * <li>write a document that describes the understanding of the existing project</li>
 * <li>add implementation that supports a file-based CSV source</li>
 * <li>add implementation that supports a SQL database source</li>
 * <li>implement {@link fa.homework.Configuration} so that it gives access to the implementations</li>
 * <li>implement {@link fa.homework.Configuration} so that it gives access to the implementations using an externally
 * defined configuration</li>
 * <li>suggest improvements to the existing interfaces</li>
 * <li>implement a main entry point that fills a data set with records from a source</li>
 * <li>implement a main entry point that dumps the content of a data set to the console standard output</li>
 * <li>write a document that describes the reached solutions</li>
 * </ul>
 */
package fa.homework;