package fa.homework;

import java.util.Map;

import fa.homework.datamodel.meta.RecordDefinition;
import fa.homework.io.Source;

public class Configuration {
	private Map<String, Source> sourceMap;
	private RecordDefinition recordDefinition;

	public Configuration(Map<String, Source> sourceMap, RecordDefinition recordDefinition) {
		this.sourceMap = sourceMap;
		this.recordDefinition = recordDefinition;
	}

	public RecordDefinition getRecordDefinition(String id) {
		// TODO
		return null;
	}

	public Source<?> getSource(String sourceId) {
		return sourceMap.get(sourceId);
	}
}
