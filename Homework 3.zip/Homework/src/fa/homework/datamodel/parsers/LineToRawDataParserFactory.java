package fa.homework.datamodel.parsers;

import fa.homework.datamodel.FileType;
import fa.homework.datamodel.parsers.EnrollmentDataLineToRawDataParser;
import fa.homework.datamodel.parsers.LineToRawDataParser;
import fa.homework.datamodel.parsers.TradingDataLineToRawDataParser;

public class LineToRawDataParserFactory<T> {
	public LineToRawDataParser<T> getParser(FileType fileType){
		if(fileType.equals(FileType.ENROLLMENT_FILE))
			return new EnrollmentDataLineToRawDataParser<T>();
		else if(fileType.equals(FileType.TRADING_FILE))
			return new TradingDataLineToRawDataParser<T>();
		return null;
	}
}

