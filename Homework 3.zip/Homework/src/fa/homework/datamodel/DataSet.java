package fa.homework.datamodel;

/**
 * Data sets are the internal structure to access records<br/>
 * Records can be appended to them, and they can be globally iterated on to access all appended records
 * @author Features Analytics
 */
public interface DataSet extends Iterable<Record> {
	/**
	 * Appends a record to this data set
	 * @param record
	 */
	public void append(Record record);
}
