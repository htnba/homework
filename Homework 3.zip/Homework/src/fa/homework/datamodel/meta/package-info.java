/**
 * This package contains the interfaces that give access to the meta-data of records
 */
package fa.homework.datamodel.meta;