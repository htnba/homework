package fa.homework.datamodel.rawdatatypes;

public interface RawData {
//	USER_ENROLLMENT("USER_ENROLLMENT", "ENROLLMENT"),
//	TRADING_DATA("TRADING_DATA", "TRADING");

//	private String fileType;
//	private String filePrefix;

//	 RawDataType(String fileType, String filePrefix) {
//		this.fileType = fileType;
//		this.filePrefix = filePrefix;
//	}
//
//	public String getFileType() {
//		return fileType;
//	}
//
//	public String getFilePrefix() {
//		return filePrefix;
//	}

//	public RawDataType getFileTypeFromFileName(String fullFilePath){
//		String[] splitPath = fullFilePath.split("/");
//		for(RawDataType rawDataType : RawDataType.values()){
//			if(splitPath[splitPath.length - 1].startsWith(rawDataType.getFilePrefix())){
//				return rawDataType;
//			}
//		}
//		return null;
//	}
}
