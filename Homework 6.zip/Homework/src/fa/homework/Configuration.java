package fa.homework;

import fa.homework.datamodel.meta.RecordDefinition;
import fa.homework.io.Source;

public class Configuration {
	private RecordDefinition recordDefinition;
	private Source<?> source;

	public Configuration(RecordDefinition recordDefinition, Source<?> source) {
		this.recordDefinition = recordDefinition;
		this.source = source;
	}

	public RecordDefinition getRecordDefinition(String id) {
		// TODO
		return null;
	}

	public Source<?> getSource(String sourceId) {
		// TODO
//		for(Source)
		return null;
	}

	public void setRecordDefinition(RecordDefinition recordDefinition) {
		this.recordDefinition = recordDefinition;
	}

	public void setSource(Source<?> source) {
		this.source = source;
	}
}
