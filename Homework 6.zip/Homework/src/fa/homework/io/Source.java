package fa.homework.io;

import fa.homework.datamodel.rawdatatypes.RawData;

/**
 * An external source provides access to raw data that represent individual records
 * @author Features Analytics
 *
 * @param <T> type of the raw data
 */
public interface Source<T> extends Iterable<T> {
	public String getId();
}
