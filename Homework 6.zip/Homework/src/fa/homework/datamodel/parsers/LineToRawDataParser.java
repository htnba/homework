//package fa.homework.datamodel.parsers;
//
//public interface LineToRawDataParser<T> {
//	public T parse(String line);
//}
