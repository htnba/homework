//package fa.homework.datamodel.parsers;
//
//public enum TradingDataFields {
//	ACCOUNTID(0),
//	TRADETIMESTAMP(1),
//	TRADEDVALUE(2);
//	private int index;
//	private TradingDataFields(int index){
//		this.index = index;
//	}
//
//	public int getIndex() {
//		return index;
//	}
//}