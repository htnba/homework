//package fa.homework.datamodel.parsers;
//
//import fa.homework.datamodel.rawdatatypes.FileType;
//
//public class LineToRawDataParserFactory<T> {
//	public LineToRawDataParser<T> getParser(FileType fileType){
//		if(fileType.equals(FileType.ENROLLMENT_FILE))
//			return new EnrollmentDataLineToRawDataParser<T>();
//		else if(fileType.equals(FileType.TRADING_FILE))
//			return new TradingDataLineToRawDataParser<T>();
//		return null;
//	}
//}
//
