//package fa.homework.datamodel.parsers;
//
//import fa.homework.datamodel.Record;
//import fa.homework.datamodel.meta.EnrollmentRawData;
//import fa.homework.datamodel.rawdatatypes.RawData;
//
//public class EnrollmentDataLineToRawDataParser<T> implements LineToRawDataParser {
//	@Override
//	public Record parse(String line) {
//		String[] splitLine = line.split(",");
//		String accountId = splitLine[EnrollmentDataFields.ACCOUNTID.getIndex()];
//		String firstName = splitLine[EnrollmentDataFields.FIRSTNAME.getIndex()];
//		String lastName = splitLine[EnrollmentDataFields.LASTNAME.getIndex()];
//		String addressLine1 = splitLine[EnrollmentDataFields.ADDRESSLINE1.getIndex()];
//		String addressLine2 = splitLine[EnrollmentDataFields.ADDRESSLINE2.getIndex()];
//		int zipCode = Integer.parseInt(splitLine[EnrollmentDataFields.ZIPCODE.getIndex()]);
//		String phoneNumber = splitLine[EnrollmentDataFields.PHONENUMBER.getIndex()];
//		long timestamp = Long.parseLong(splitLine[EnrollmentDataFields.ENROLLMENTTIMESTAMP.getIndex()]);
//
//		return new EnrollmentRawData(accountId, firstName, lastName, addressLine1,
//				addressLine2, zipCode, phoneNumber, timestamp);
//	}
//}