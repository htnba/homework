package fa.homework.datamodel.meta;

import java.util.UUID;

public class AccountIdFieldDefinition implements FieldDefinition {
	private String id;
	private String name;
	private FieldType fieldType;

	public AccountIdFieldDefinition(String id, String name, FieldType fieldType) {
		this.id = "AccountId";
		this.name = "accountId";
		this.fieldType = FieldType.TEXT;
	}

	public AccountIdFieldDefinition() {
	}

	@Override public String getId() {
		return null;
	}

	@Override public String getName() {
		return null;
	}

	@Override public FieldType getType() {
		return null;
	}
}
