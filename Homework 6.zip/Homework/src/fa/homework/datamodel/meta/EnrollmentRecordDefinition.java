package fa.homework.datamodel.meta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fa.homework.datamodel.Record;

public class EnrollmentRecordDefinition implements RecordDefinition{

	private List<FieldDefinition> fieldDefinitionList;

	public EnrollmentRecordDefinition() {
		this.fieldDefinitionList = new ArrayList<>();
		fieldDefinitionList.add(new AccountIdFieldDefinition());
	}

	@Override public List<FieldDefinition> getFields() {
		return fieldDefinitionList;
	}

	@Override public <T extends String> Record createRecord(T rawData) {
		String[] splitString = rawData.split(",");
		Map<FieldDefinition, String> fieldDefinitionMap = new HashMap<>();
		for(int i=0; i<this.getFields().size();i++){
			FieldDefinition fieldDefinition = this.getFields().get(i);
			String value = splitString[i];
			fieldDefinitionMap.put(fieldDefinition, value);
		}
		return new EnrollmentRecord(fieldDefinitionMap);
	}
}
