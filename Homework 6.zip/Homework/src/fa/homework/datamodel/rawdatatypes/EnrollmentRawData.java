//package fa.homework.datamodel.meta;
//
//import fa.homework.datamodel.meta.FieldType;
//import fa.homework.datamodel.rawdatatypes.RawData;
//
//public class EnrollmentRawData<T> implements RawData {
//	private FieldDefinition accountId;
//	private FieldDefinition firstName;
//	private FieldDefinition lastName;
//	private FieldDefinition addressLine1;
//	private FieldDefinition addressLine2;
//	private FieldDefinition zipCode;
//	private FieldDefinition phoneNumber;
//	private FieldDefinition enrollmentTimestamp;
//
//	public EnrollmentRawData(FieldDefinition accountId, FieldDefinition firstName, FieldDefinition lastName,
//			FieldDefinition addressLine1, FieldDefinition addressLine2, FieldDefinition zipCode,
//			FieldDefinition phoneNumber, FieldDefinition enrollmentTimestamp) {
//		this.accountId = accountId;
//		this.firstName = firstName;
//		this.lastName = lastName;
//		this.addressLine1 = addressLine1;
//		this.addressLine2 = addressLine2;
//		this.zipCode = zipCode;
//		this.phoneNumber = phoneNumber;
//		this.enrollmentTimestamp = enrollmentTimestamp;
//	}
//
//	public FieldDefinition getAccountId() {
//		return accountId;
//	}
//
//	public void setAccountId(FieldDefinition accountId) {
//		this.accountId = accountId;
//	}
//
//	public FieldDefinition getFirstName() {
//		return firstName;
//	}
//
//	public void setFirstName(FieldDefinition firstName) {
//		this.firstName = firstName;
//	}
//
//	public FieldDefinition getLastName() {
//		return lastName;
//	}
//
//	public void setLastName(FieldDefinition lastName) {
//		this.lastName = lastName;
//	}
//
//	public FieldDefinition getAddressLine1() {
//		return addressLine1;
//	}
//
//	public void setAddressLine1(FieldDefinition addressLine1) {
//		this.addressLine1 = addressLine1;
//	}
//
//	public FieldDefinition getAddressLine2() {
//		return addressLine2;
//	}
//
//	public void setAddressLine2(FieldDefinition addressLine2) {
//		this.addressLine2 = addressLine2;
//	}
//
//	public FieldDefinition getZipCode() {
//		return zipCode;
//	}
//
//	public void setZipCode(FieldDefinition zipCode) {
//		this.zipCode = zipCode;
//	}
//
//	public FieldDefinition getPhoneNumber() {
//		return phoneNumber;
//	}
//
//	public void setPhoneNumber(FieldDefinition phoneNumber) {
//		this.phoneNumber = phoneNumber;
//	}
//
//	public FieldDefinition getEnrollmentTimestamp() {
//		return enrollmentTimestamp;
//	}
//
//	public void setEnrollmentTimestamp(FieldDefinition enrollmentTimestamp) {
//		this.enrollmentTimestamp = enrollmentTimestamp;
//	}
//}
