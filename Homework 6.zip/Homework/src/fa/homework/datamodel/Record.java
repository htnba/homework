package fa.homework.datamodel;

/**
 * Gives access to the data within a single record of a data set
 * @author Features Analytics
 */
public interface Record {
	/**
	 * Returns the value of the specified field
	 * @param <T>
	 * @param fieldId
	 * @return value of the field within this record
	 */
	public <T> T getValue(String fieldId);
}
