package fa.homework;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import fa.homework.datamodel.DataSet;
import fa.homework.datamodel.Record;
import fa.homework.datamodel.meta.EnrollmentRecordDefinition;
import fa.homework.datamodel.meta.RecordDefinition;
import fa.homework.io.FileSource;
import fa.homework.io.Source;

/**
 * implement a main entry point that fills a data set with records from a source
 */
public class IngestionService {
	private List<Configuration> configurations;

	public IngestionService(List<Configuration> configurations) {
		this.configurations = configurations;
	}

	public IngestionService() {
		Configuration configuration = new Configuration(new EnrollmentRecordDefinition(), new FileSource("~/Downloads/temp.csv"));
		List<Configuration> configurationList = new ArrayList<>();
		configurationList.add(configuration);
	}

	public DataSet ingestRecordsFromSource(){
		DataSet enrollmentDataSet = new DataSet() {
			List<Record> records = new ArrayList<>();
			@Override public void append(Record record) {
				records.add(record);
			}

			@Override public Iterator<Record> iterator() {
				return records.iterator();
			}
		};
		for(Configuration configuration : this.configurations){
			Source source = configuration.getSource("file");
			RecordDefinition recordDefinition = configuration.getRecordDefinition("enrollmentRecordDefinition");
			Iterator<String> iterator = source.iterator();

			while (iterator.hasNext()){
				Record record = recordDefinition.createRecord(iterator.next());
				enrollmentDataSet.append(record);
			}
		}
		return enrollmentDataSet;
	}
}
