package fa.homework.datamodel.meta;

import java.util.Map;

import fa.homework.datamodel.Record;

public class EnrollmentRecord implements Record {
	Map<FieldDefinition, String> fieldDefinitionMap;

	public EnrollmentRecord(Map<FieldDefinition, String> fieldDefinitionMap) {
		this.fieldDefinitionMap = fieldDefinitionMap;
	}

	@Override public <T> T getValue(String fieldId) {
		// iterate map and return if field id matches key.fieldID
		return null;
	}
}
