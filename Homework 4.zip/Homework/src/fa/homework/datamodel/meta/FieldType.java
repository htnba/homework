package fa.homework.datamodel.meta;

import java.time.LocalDateTime;

/**
 * Handles behavior associated to each supported field data type
 * @author Features Analytics
 */
public enum FieldType {
	/** Text */
	TEXT(String.class),

	/** Time */
	TIME(LocalDateTime.class),

	/** Integer numbers */
	INTEGER(Long.class),

	/** Decimal numbers */
	DECIMAL(Double.class);

	/** Java type used to hold the values */
	public final Class<?> JAVA_TYPE;

	/**
	 * Constructor
	 * @param javaType type used to hold the values
	 */
	private FieldType(Class<?> javaType) {
		JAVA_TYPE = javaType;
	}

	public Class<?> getJAVA_TYPE() {
		return JAVA_TYPE;
	}
}
