package fa.homework.datamodel.meta;

import java.util.List;

import fa.homework.datamodel.Record;
import fa.homework.io.Source;

/**
 * Gives access to the definition of a record within a data set
 * @author Features Analytics
 */
public interface RecordDefinition {
	/**
	 * Returns the definitions of all fields of the records of the data set
	 * @return list of field definitions
	 */
	public List<FieldDefinition> getFields();

	/**
	 * Creates a new record by consuming raw data
	 * @param rawData raw data obtained from a {@link Source}
	 * @param <T> type of the raw data
	 * @return record based on the raw data
	 */
	public <T extends String> Record createRecord(T rawData);
}
