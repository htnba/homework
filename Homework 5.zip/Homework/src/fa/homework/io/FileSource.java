package fa.homework.io;
//
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Iterator;
//import java.util.List;
//
//import fa.homework.datamodel.FileType;
//import fa.homework.datamodel.parsers.LineToRawDataParser;
//import fa.homework.datamodel.parsers.LineToRawDataParserFactory;
//import fa.homework.datamodeldel.rawdatatypes.RawData;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FileSource implements Source{
	private String filePath;
	private String id;

	public FileSource(String filePath) {
		this.filePath = filePath;
	}

	@Override public Iterator<String> iterator() {
		List<String> rawDataList = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line;
			while ((line = br.readLine()) != null) {
				rawDataList.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return rawDataList.iterator();
	}

	@Override
	public String getId() {
		return id;
	}

	//	private String filePath;
//	private LineToRawDataParserFactory lineToRawDataParserFactory;
//
//	public FileSource(String filePath, LineToRawDataParserFactory lineToRawDataParserFactory) {
//		this.filePath = filePath;
//		this.lineToRawDataParserFactory = lineToRawDataParserFactory;
//	}
//
//	@Override public Iterator<T> iterator() {
//		FileType fileType = getFileTypeFromFilePath(this.filePath);
//		if(fileType == null){
//			// logger.error("unsupported file type encountered. file name is {}", this.fileName);
//			return null;
//		}
//		LineToRawDataParser<T> parser = lineToRawDataParserFactory.getParser(fileType);
//		List<T> rawDataList = new ArrayList<>();
//		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
//			String line;
//			while ((line = br.readLine()) != null) {
//				rawDataList.add(parser.parse(line));
//			}
//
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		return rawDataList.iterator();
//	}
//
//	private FileType getFileTypeFromFilePath(String filePath) {
//		for(FileType f: FileType.values()){
//			if(filePath.startsWith(f.getPrefix()))
//				return f;
//		}
//		return null;
//	}
}
