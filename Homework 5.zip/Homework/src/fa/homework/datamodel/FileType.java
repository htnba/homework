package fa.homework.datamodel;

public enum FileType {
	ENROLLMENT_FILE("enroll"),
	TRADING_FILE("trading");

	private String prefix;
	private FileType(String prefix) {
		this.prefix = prefix;
	}

	public String getPrefix() {
		return prefix;
	}

}
