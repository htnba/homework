package fa.homework.datamodel.rawdatatypes;

public class TradingRawData implements RawData {
	private String accountId;
	private long tradeTimestamp;
	private double tradedValue;

	public TradingRawData(String accountId, long tradeTimestamp, double tradedValue) {
		this.accountId = accountId;
		this.tradeTimestamp = tradeTimestamp;
		this.tradedValue = tradedValue;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public long getTradeTimestamp() {
		return tradeTimestamp;
	}

	public void setTradeTimestamp(long tradeTimestamp) {
		this.tradeTimestamp = tradeTimestamp;
	}

	public double getTradedValue() {
		return tradedValue;
	}

	public void setTradedValue(double tradedValue) {
		this.tradedValue = tradedValue;
	}
}
