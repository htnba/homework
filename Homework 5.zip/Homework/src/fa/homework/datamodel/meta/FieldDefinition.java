package fa.homework.datamodel.meta;

/**
 * Gives access to the definition of a field within a record
 * @author Features Analytics
 */
public interface FieldDefinition {
	/** Technical identifier of the field */
	public String getId();

	/** Name of the field for user interactions */
	public String getName();

	/** Type of the data contained in the field */
	public FieldType getType();
}
