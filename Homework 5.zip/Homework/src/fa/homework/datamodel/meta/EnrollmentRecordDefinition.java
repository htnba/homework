package fa.homework.datamodel.meta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fa.homework.datamodel.Record;
import fa.homework.datamodel.parsers.EnrollmentDataFields;

public class EnrollmentRecordDefinition implements RecordDefinition{

	private List<FieldDefinition> fieldDefinitionList;

	public EnrollmentRecordDefinition() {
		this.fieldDefinitionList = new ArrayList<>();
		fieldDefinitionList.add(new AccountIdFieldDefinition());
	}

	@Override public List<FieldDefinition> getFields() {
		return fieldDefinitionList;
	}

	@Override public <T extends String> Record createRecord(T rawData) {
		String[] splitString = rawData.split(",");
		Map<FieldDefinition, String> fieldDefinitionMap = new HashMap<>();
		for(int i=0; i<this.getFields().size();i++){
			FieldDefinition fieldDefinition = this.getFields().get(i);
			String value = splitString[i];
			fieldDefinitionMap.put(fieldDefinition, value);
		}
		return new EnrollmentRecord(fieldDefinitionMap);
//		String accountId = splitLine[EnrollmentDataFields.ACCOUNTID.getIndex()];
//		String firstName = splitLine[EnrollmentDataFields.FIRSTNAME.getIndex()];
//		String lastName = splitLine[EnrollmentDataFields.LASTNAME.getIndex()];
//		String addressLine1 = splitLine[EnrollmentDataFields.ADDRESSLINE1.getIndex()];
//		String addressLine2 = splitLine[EnrollmentDataFields.ADDRESSLINE2.getIndex()];
//		int zipCode = Integer.parseInt(splitLine[EnrollmentDataFields.ZIPCODE.getIndex()]);
//		String phoneNumber = splitLine[EnrollmentDataFields.PHONENUMBER.getIndex()];
//		long timestamp = Long.parseLong(splitLine[EnrollmentDataFields.ENROLLMENTTIMESTAMP.getIndex()]);

	}
}
